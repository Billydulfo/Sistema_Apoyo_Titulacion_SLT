package main;

import vista.prueba;

public class Main {

  
    public static void main(String[] args){
       prueba p = new prueba();
       p.setLocationRelativeTo(null);
       p.setVisible(true);
    }
}
